//Sadaf Ahmad 

 

$(function(){


	  var defaults = {
	  units: 'f'}


 var plugin = this;

        //define element
        var el = $(this);
        
        //api URL
        var apiURL;

        //define settings
        plugin.settings = {}
 
        //merge defaults and options
        plugin.settings = $.extend({}, defaults);
        
        //define settings namespace
        var s = plugin.settings;


	$("a").on("click",function(e){

		e.preventDefault();
		//alert(this.text);
		var city=this.text.toLowerCase();
		$.ajax({
			type:'GET',
			url:'http://api.openweathermap.org/data/2.5/weather?q='+ city +' &appid=2de143494c0b295cca9337e1e96b00e0' ,
			success: function(data){
							if(s.units == 'f') {
	        	
		        	//define temperature as fahrenheit
		        	var temperature = Math.round(((data.main.temp - 273.15) * 1.8) + 32) + '°F';
		        	
		        	//define min temperature as fahrenheit
		        	var minTemperature = Math.round(((data.main.temp_min - 273.15) * 1.8) + 32) + '°F';
		        	
		        	//define max temperature as fahrenheit
		        	var maxTemperature = Math.round(((data.main.temp_max - 273.15) * 1.8) + 32) + '°F';
	        	
	        	} else {
		        	
		        	//define temperature as celsius
		        	var temperature = Math.round(data.main.temp - 273.15) + '°C';
		        	
		        	//define min temperature as celsius
		        	var minTemperature = Math.round(data.main.temp_min - 273.15) + '°C';
		        	
		        	//define max temperature as celsius
		        	var maxTemperature = Math.round(data.main.temp_max - 273.15) + '°C';
	        	
	        	}
	        	


				//console.log(data.name);
				$("#container").html(data.name +":" + data.main.temp + data.units);
			}

		});
	});
});

